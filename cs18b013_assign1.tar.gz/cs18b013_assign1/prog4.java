import java.util.Scanner;

public class prog4{
	public static void main(String[] args){
		char c;
		if((c>='a'&& c<='z')||(c>='A' &&c<='Z')){
			System.out.println(c +"is aphabet");
		}
		else
			System.out.println(c+"is not alphabet");
	}
}
			
